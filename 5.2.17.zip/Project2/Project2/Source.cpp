#include<iostream>
#include<fstream>
#include<string>
using namespace std; 
fstream fin("fisier.txt");

class TrieNode {
public:

	bool is_end;

	/* implementarea TST */
	TrieNode* left, * mid, * right;
	char c;

	TrieNode(char _c) :c(_c), left(NULL), mid(NULL), right(NULL), is_end(false) {

	}
	~TrieNode() {
		if (left)
			delete left;
		if (right)
			delete right;
		if (mid)
			delete mid;
	}
};

class SpellChecker {
private:
	TrieNode* root;
public:
	SpellChecker() {
		root = NULL;
	}
	~SpellChecker() {
		delete root;
	}
	
	TrieNode* put(TrieNode* node, const string& str, int index) {
		if (!node) {
			node = new TrieNode(str[index]);
		}

		if (node->c > str[index])
			node->left = put(node->left, str, index);
		else if (node->c < str[index])
			node->right = put(node->right, str, index);
		else if (index < str.size() - 1) {
			node->mid = put(node->mid, str, index + 1);
		}
		else
			node->is_end = true;

		return node;
	}
	// Functie ce insereaza un cuvant in arbore
	void insert(string word) {
		root = put(root, word, 0);
	}

	// Functia ce ne returneaza daca un anumit cuvant face parte din arbore sau nu 
	TrieNode* get(TrieNode* node, const string& str, int index) {
		if (node == NULL)
			return NULL;

		if (node->c > str[index])
			return get(node->left, str, index);
		if (node->c < str[index])
			return get(node->right, str, index);
		if (index < str.size() - 1)
			return get(node->mid, str, index + 1);
		return node;
	}
	bool search(string word) {
		TrieNode* p = get(root, word, 0);

		return p && p->is_end;
	}


};
int main()
{
	SpellChecker a;
	string s, p;
	cout << "Continutul dictionarului este:" << endl; 
	while (fin >> s)
	{
		a.insert(s);
		cout << s << endl;
	}
	cout << "....................................." << endl; 
	cout << "Introduceti cuvantul pe care doriti sa-l cautati: "; 
	cin >> p; 
	if (a.search(p) == 0)
		cout << "Not found";
	else
		cout << "Found";

	return 0;
}